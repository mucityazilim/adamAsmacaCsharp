﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace admAsm
{
    public partial class frmOyun : Form
    {
        public frmOyun()
        {
            InitializeComponent();
        }


        string kelime = "";
        string tahmin = "";
        int len = 0, hak = 0;
        string[] kelimeler;

        public void oyunOlustur()
        {

            StreamReader sr = new StreamReader("kelimeler.txt");
            while (sr.ReadLine() != null)
                len++;
            sr.Close();

            kelimeler = new string[len];
            sr = new StreamReader("kelimeler.txt");
            for (int j = 0; j < len; j++)
            {
                kelimeler[j] = sr.ReadLine();
            }
            sr.Close();

            if (len <= 0)
                MessageBox.Show("Kelime havuzunuz boş ");
            else
            {
                Random rnd = new Random();
                int i = rnd.Next(len);
                //MessageBox.Show(i.ToString());
                kelime = kelimeler[i];
                //lblKelime.Text = kelime;
                lblKelime.Text = "";
                tahmin = "";
                for (int k = 0; k < kelime.Length; k++)
                {
                    tahmin += "*";
                }
                lblKelime.Text = tahmin.ToString();
                hak = kelime.Length + 2;
                lblHak.Text = hak.ToString();
            }


        }
        void dosyayaKaydet(string  sonuc )
        {
            FileStream fs = new FileStream( "skorlar.txt",  FileMode.Append, FileAccess.Write );
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(textBox1.Text + "  :  " + sonuc);
            sw.Close(); 

        }
        public void oyunBaslat()
        {
            char harf = Convert.ToChar(txtHarf.Text);
            string temp = "";
            for (int i = 0; i < kelime.Length; i++)
            {

                if (tahmin[i] != '*')
                {
                    temp += tahmin[i];
                }
                else if (harf == kelime[i])
                    temp += harf;
                else
                    temp += '*';
            }
            tahmin = temp;
            lblKelime.Text = temp.ToString();

        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (txtHarf.Text == "")
                MessageBox.Show("harf girin ");
            else
            {
                oyunBaslat();
                hak--;
                lblHak.Text = hak.ToString();
                if (hak == 0)
                {
                    MessageBox.Show("Malesef hakkınız bitti ve ASILDINIZ!");
                    MessageBox.Show("kelime : " + kelime);
                    button2.Enabled = false;
                    dosyayaKaydet("Başarısız"); 
                }
                else if (kelime == tahmin)
                {
                    MessageBox.Show("Tebrikler asılmaktan kurtuldunuz ");
                    dosyayaKaydet("SÜPER" );
                    button2.Enabled = false; 
                }
                lblGirilenHarfler.Text += txtHarf.Text + " ";


            }
            txtHarf.Text = ""; 

        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear(); 
            StreamReader sr = new StreamReader("skorlar.txt");
            string kelime = "";
            while (true)
            {
                kelime = sr.ReadLine();
                if (kelime==null )
                {
                    break; 
                }
                listBox1.Items.Add(kelime); 
            }
            sr.Close(); 
        }

        private void frmOyun_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
                MessageBox.Show("Lütfen ad soyad bilgilerinizi giriniz ");
            else
            {
                button2.Enabled = true; 
                len = 0;
                hak = 0;
                lblGirilenHarfler.Text = "";
                lblKelime.Text = "";
                hak = 0; 
                lblGirilenHarfler.Text = ""; 
                oyunOlustur();
            }
        }
    }
}
