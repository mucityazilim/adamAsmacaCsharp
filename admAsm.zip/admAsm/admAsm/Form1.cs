﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

// Bilgisayar Mühendisi Sadık ŞAHİN

namespace admAsm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
                MessageBox.Show("Kelime giriniz ");
            else
                listBox1.Items.Add(textBox1.Text);
            textBox1.Text = "";

        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            textBox1.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
            if (index == -1)
                MessageBox.Show("Lütfen listeden kelime seçiniz ");
            else
            {
                listBox1.Items.RemoveAt(index);
            }


        }

        private void button6_Click(object sender, EventArgs e)
        {

            if (textBox2.Text == "")
                MessageBox.Show("Kelime giriniz ");
            else
            {
                FileStream fs = new FileStream("kelimeler.txt", FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine(textBox2.Text);
                sw.Close();
            }
            textBox2.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            StreamReader sr = new StreamReader("kelimeler.txt");
            string kelime;
            while (true)
            {
                kelime = sr.ReadLine();
                if (kelime == null)
                    break;
                listBox1.Items.Add(kelime);
            }
            sr.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            int cnt = listBox1.Items.Count;
            if (cnt <= 0)
                MessageBox.Show("liste boş");
            else
            {
                StreamWriter sw = new StreamWriter("kelimeler.txt");

                for (int i = 0; i < cnt; i++)
                {
                    sw.WriteLine(listBox1.Items[i].ToString());
                }
                sw.Close();
            }

            
            listBox1.Items.Clear();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new     StreamWriter("kelimeler.txt");
            sw.Close(); 
        }

        private void button8_Click(object sender, EventArgs e)
        {
            frmOyun fr = new frmOyun();
            fr.Show(); 
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
